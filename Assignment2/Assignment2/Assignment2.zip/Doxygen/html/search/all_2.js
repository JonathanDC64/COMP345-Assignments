var searchData=
[
  ['exists',['exists',['../classstopword.html#a11210085752c2b3d63055490c13b6666',1,'stopword']]]
];

var searchData=
[
  ['stopword',['stopword',['../classstopword.html',1,'']]]
];

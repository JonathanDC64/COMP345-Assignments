var searchData=
[
  ['_7edocument',['~document',['../classdocument.html#afff6a78ede7767d8cbc0cb4566ae64da',1,'document']]],
  ['_7equery_5fresult',['~query_result',['../classquery__result.html#a85eee76ed372ad28ab7347053633714a',1,'query_result']]],
  ['_7estopword',['~stopword',['../classstopword.html#aee102291edf88348aad736a35c961fdf',1,'stopword']]],
  ['_7etokenizer',['~tokenizer',['../classtokenizer.html#a458162a13637fc34d706f8743ffa8909',1,'tokenizer']]]
];

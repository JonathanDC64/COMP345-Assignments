var searchData=
[
  ['query',['query',['../classindexer.html#ae72394af5bf9eb84cf2b245f19d8cf27',1,'indexer']]],
  ['query_5fresult',['query_result',['../classquery__result.html',1,'query_result'],['../classquery__result.html#a957a24bae5c9fcf83099d7fa2ece2647',1,'query_result::query_result()']]]
];

var searchData=
[
  ['query_5fresult',['query_result',['../classquery__result.html',1,'']]]
];

var searchData=
[
  ['document',['document',['../classdocument.html#af1a85718219b8da6f1befaac0bf87989',1,'document::document()'],['../classdocument.html#a750ac91b3537c59d0fff8e4a01085c98',1,'document::document(const std::string &amp;file_name)']]]
];

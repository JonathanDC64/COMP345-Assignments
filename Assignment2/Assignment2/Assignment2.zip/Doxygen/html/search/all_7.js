var searchData=
[
  ['remove_5fstop_5fwords',['remove_stop_words',['../classindexer.html#afdaec83c53cbc4df71436a4c936a2e89',1,'indexer']]]
];

var searchData=
[
  ['sanitize',['sanitize',['../classtokenizer.html#a5d553b843e67154be958b849fbf20b62',1,'tokenizer']]],
  ['size',['size',['../classdocument.html#aee0dba5f11baeb3b7da786bdd320a576',1,'document::size()'],['../classindexer.html#a227b90870b8807668485754e402b8a60',1,'indexer::size()']]],
  ['stopword',['stopword',['../classstopword.html#a27bd1c2cc2608cc3fef800a6e1c2edd6',1,'stopword::stopword()'],['../classstopword.html#accb49b6c9d5ddc75002348a869df5619',1,'stopword::stopword(const std::string &amp;file_name)']]]
];

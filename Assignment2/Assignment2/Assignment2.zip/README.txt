1. Group Members (Name/ID)
Jonathan Del Corpo - 40025207
Justin Baron - 40018436
Ahnaf Shahriar - 40025107


2. Operating System used for development.
Windows 10

3. IDE used for development (Eclipse, Netbeans, etc.)
Visual Studio

4. Compiler name and version used
gcc version 4.9.2


5. Test input files and output produced
INPUT FILES:
index.txt
stopwords.txt
Doc1.txt
Doc2.txt
Doc3.txt

OUTPUT:
Example of output:

Please enter a search query : apple

Ranked search Results:

Doc. Name              Score
1: Doc1.txt       |    0.3012
2: Doc2.txt       |     0.000
3: Doc3.txt       |     0.000

Perform another search?: (y/n) : y

Please enter a search query : orange citrus apple banana an by from or

Ranked search Results:

Doc. Name              Score
1: Doc2.txt       |    0.4859
2: Doc1.txt       |    0.3131
3: Doc3.txt       |    0.2738

Perform another search?: (y/n) :
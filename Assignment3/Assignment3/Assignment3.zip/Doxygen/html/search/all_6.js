var searchData=
[
  ['name',['name',['../classindex__item.html#a1bcb5c577c3986549330c3aa283a6a5e',1,'index_item']]]
];

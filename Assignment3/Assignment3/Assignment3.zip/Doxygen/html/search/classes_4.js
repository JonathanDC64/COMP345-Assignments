var searchData=
[
  ['sentence',['sentence',['../classsentence.html',1,'']]],
  ['sentence_5findexer',['sentence_indexer',['../classsentence__indexer.html',1,'']]],
  ['sentence_5ftokenizer',['sentence_tokenizer',['../classsentence__tokenizer.html',1,'']]],
  ['stopword',['stopword',['../classstopword.html',1,'']]]
];

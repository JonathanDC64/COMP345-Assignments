var searchData=
[
  ['sentence',['sentence',['../classsentence.html',1,'sentence'],['../classsentence.html#a458e5abe0d27f8972771153e72667673',1,'sentence::sentence()'],['../classsentence.html#ade30f24b62f56cf53fd38d0fb541082c',1,'sentence::sentence(const document &amp;doc, long pos, long endPos)']]],
  ['sentence_5findexer',['sentence_indexer',['../classsentence__indexer.html',1,'sentence_indexer'],['../classsentence__indexer.html#a365d5a760a116eb4f48fe8fdbdeb0421',1,'sentence_indexer::sentence_indexer()']]],
  ['sentence_5ftokenizer',['sentence_tokenizer',['../classsentence__tokenizer.html',1,'sentence_tokenizer'],['../classsentence__tokenizer.html#aa36679bc4afb2788d5c81fcee4ab9e0b',1,'sentence_tokenizer::sentence_tokenizer()']]],
  ['size',['size',['../classdocument.html#aad56f03674964346987dc7afd18aacf1',1,'document::size()'],['../classindex__item.html#a7c16d6bca513663fab66d40a6c0289a9',1,'index_item::size()'],['../classindexer.html#af54a50fbe5e93e780394d6fede3d2039',1,'indexer::size()'],['../classsentence.html#ad673d4210850083f621383e2629a7b0e',1,'sentence::size()']]],
  ['stopword',['stopword',['../classstopword.html',1,'stopword'],['../classstopword.html#a27bd1c2cc2608cc3fef800a6e1c2edd6',1,'stopword::stopword()'],['../classstopword.html#accb49b6c9d5ddc75002348a869df5619',1,'stopword::stopword(const std::string &amp;file_name)']]]
];

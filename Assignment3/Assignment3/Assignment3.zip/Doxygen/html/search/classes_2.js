var searchData=
[
  ['index_5fitem',['index_item',['../classindex__item.html',1,'']]],
  ['indexer',['indexer',['../classindexer.html',1,'']]],
  ['indexer_3c_20document_2c_20word_5ftokenizer_20_3e',['indexer&lt; document, word_tokenizer &gt;',['../classindexer.html',1,'']]],
  ['indexer_3c_20sentence_2c_20sentence_5ftokenizer_20_3e',['indexer&lt; sentence, sentence_tokenizer &gt;',['../classindexer.html',1,'']]]
];

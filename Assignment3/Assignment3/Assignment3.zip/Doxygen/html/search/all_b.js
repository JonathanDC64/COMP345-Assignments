var searchData=
[
  ['tokenize',['tokenize',['../classabstract__tokenizer.html#aeea4a861fdfa18351555b0d00a378165',1,'abstract_tokenizer::tokenize()'],['../classsentence__tokenizer.html#abd8fdaae180f7c8c6dea91c68f7b8865',1,'sentence_tokenizer::tokenize()'],['../classword__tokenizer.html#ac51f61652880447073e16fdb0f471fbe',1,'word_tokenizer::tokenize()']]]
];

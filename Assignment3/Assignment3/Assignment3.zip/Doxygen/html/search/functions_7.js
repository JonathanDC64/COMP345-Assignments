var searchData=
[
  ['query',['query',['../classdocument__indexer.html#acdb8dcbe7827e775ab8d64e79212ea36',1,'document_indexer::query()'],['../classindexer.html#a9a7679edcc3114613dac13b688c0e4b2',1,'indexer::query()'],['../classsentence__indexer.html#a039940ff3461bb8fa95b66aa9b5f8496',1,'sentence_indexer::query()']]],
  ['query_5fresult',['query_result',['../classquery__result.html#a04c9ec02fbb2014f14cc5f49a3fb708a',1,'query_result']]]
];

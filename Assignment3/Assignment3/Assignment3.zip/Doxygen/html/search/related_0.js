var searchData=
[
  ['gtscore',['gtScore',['../classindexer.html#af90a86217251694caa9471be14515ee9',1,'indexer']]],
  ['gtscoregrouped',['gtScoreGrouped',['../classsentence__indexer.html#a105a138776c9677f92568db3f53d91f2',1,'sentence_indexer']]]
];

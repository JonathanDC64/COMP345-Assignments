var searchData=
[
  ['remove_5fstop_5fwords',['remove_stop_words',['../classindexer.html#aad6e8ddbe8103aa48965f3a4f7aea2c0',1,'indexer']]]
];

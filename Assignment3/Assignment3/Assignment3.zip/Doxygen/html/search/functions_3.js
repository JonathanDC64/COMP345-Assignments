var searchData=
[
  ['get_5fpos',['get_pos',['../classsentence.html#a033a9fd50b254e87d5303a23b2f02295',1,'sentence']]]
];

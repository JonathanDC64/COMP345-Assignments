var searchData=
[
  ['get_5fpos',['get_pos',['../classsentence.html#a033a9fd50b254e87d5303a23b2f02295',1,'sentence']]],
  ['gtscore',['gtScore',['../classindexer.html#af90a86217251694caa9471be14515ee9',1,'indexer']]],
  ['gtscoregrouped',['gtScoreGrouped',['../classsentence__indexer.html#a105a138776c9677f92568db3f53d91f2',1,'sentence_indexer']]]
];

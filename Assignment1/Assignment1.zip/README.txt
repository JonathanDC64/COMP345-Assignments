1. Group Members (Name/ID)
Jonathan Del Corpo - 40025207
Justin Baron - 40018436
Ahnaf Shahriar - 40025107


2. Operating System used for development.
Windows 10

3. IDE used for development (Eclipse, Netbeans, etc.)
Visual Studio

4. Compiler name and version used
gcc version 4.9.2


5. Test input files and output produced
INPUT FILES:
index.txt
dictionary.txt
Doc1.txt
Doc2.txt
Doc3.txt

OUTPUT:
------------------------------------------------
| Dictionary  | Doc1.txt | Doc2.txt | Doc3.txt |
------------------------------------------------
| a           |        0 |        0 |        1 |
| also        |        0 |        1 |        0 |
| an          |        0 |        0 |        1 |
| apple       |        2 |        0 |        0 |
| are         |        2 |        0 |        0 |
| as          |        0 |        1 |        0 |
| aurantium   |        0 |        1 |        0 |
| banana      |        0 |        0 |        1 |
| bananas     |        0 |        0 |        2 |
| be          |        0 |        0 |        1 |
| berry       |        0 |        0 |        1 |
| bitter      |        0 |        1 |        0 |
| botanically |        0 |        0 |        1 |
| by          |        1 |        0 |        1 |
| called      |        0 |        1 |        1 |
| citrus      |        0 |        3 |        0 |
| contrast    |        0 |        0 |        1 |
| control     |        1 |        0 |        0 |
| cooking     |        0 |        0 |        1 |
| countries   |        0 |        0 |        1 |
| cultivars   |        1 |        0 |        0 |
| dessert     |        0 |        0 |        1 |
| distinguish |        0 |        1 |        0 |
| edible      |        0 |        0 |        1 |
| family      |        0 |        1 |        0 |
| flowering   |        0 |        0 |        1 |
| for         |        0 |        0 |        1 |
| from        |        1 |        1 |        0 |
| fruit       |        0 |        1 |        1 |
| generally   |        1 |        0 |        0 |
| genus       |        0 |        0 |        1 |
| grafting    |        1 |        0 |        0 |
| grown       |        1 |        0 |        0 |
| herbaceous  |        0 |        0 |        1 |
| if          |        1 |        0 |        0 |
| in          |        0 |        1 |        3 |
| is          |        0 |        2 |        1 |
| it          |        0 |        2 |        0 |
| kinds       |        0 |        0 |        1 |
| large       |        1 |        0 |        1 |
| may         |        0 |        0 |        1 |
| musa        |        0 |        0 |        1 |
| of          |        1 |        1 |        1 |
| onto        |        1 |        0 |        0 |
| orange      |        0 |        3 |        0 |
| plantains   |        0 |        0 |        1 |
| plants      |        0 |        0 |        1 |
| produced    |        0 |        0 |        1 |
| propagated  |        1 |        0 |        0 |
| referred    |        0 |        1 |        0 |
| related     |        0 |        1 |        0 |
| resulting   |        1 |        0 |        0 |
| rootstocks  |        1 |        0 |        0 |
| rutaceae    |        0 |        1 |        0 |
| seed        |        1 |        0 |        0 |
| several     |        0 |        0 |        1 |
| sinensis    |        0 |        1 |        0 |
| size        |        1 |        0 |        0 |
| some        |        0 |        0 |        1 |
| species     |        0 |        1 |        0 |
| sweet       |        0 |        1 |        0 |
| the         |        2 |        5 |        2 |
| to          |        0 |        2 |        1 |
| tree        |        1 |        0 |        0 |
| trees       |        1 |        0 |        0 |
| used        |        0 |        0 |        1 |
| which       |        1 |        0 |        0 |
------------------------------------------------
| Totals      |       25 |       34 |       38 |
------------------------------------------------

------------------------------------------------
| Dictionary  | Doc1.txt | Doc2.txt | Doc3.txt |
------------------------------------------------
| also        |        0 |        1 |        0 |
| apple       |        2 |        0 |        0 |
| aurantium   |        0 |        1 |        0 |
| banana      |        0 |        0 |        1 |
| bananas     |        0 |        0 |        2 |
| berry       |        0 |        0 |        1 |
| bitter      |        0 |        1 |        0 |
| botanically |        0 |        0 |        1 |
| called      |        0 |        1 |        1 |
| citrus      |        0 |        3 |        0 |
| contrast    |        0 |        0 |        1 |
| control     |        1 |        0 |        0 |
| cooking     |        0 |        0 |        1 |
| countries   |        0 |        0 |        1 |
| cultivars   |        1 |        0 |        0 |
| dessert     |        0 |        0 |        1 |
| distinguish |        0 |        1 |        0 |
| edible      |        0 |        0 |        1 |
| family      |        0 |        1 |        0 |
| flowering   |        0 |        0 |        1 |
| fruit       |        0 |        1 |        1 |
| generally   |        1 |        0 |        0 |
| genus       |        0 |        0 |        1 |
| grafting    |        1 |        0 |        0 |
| grown       |        1 |        0 |        0 |
| herbaceous  |        0 |        0 |        1 |
| kinds       |        0 |        0 |        1 |
| large       |        1 |        0 |        1 |
| may         |        0 |        0 |        1 |
| musa        |        0 |        0 |        1 |
| onto        |        1 |        0 |        0 |
| orange      |        0 |        3 |        0 |
| plantains   |        0 |        0 |        1 |
| plants      |        0 |        0 |        1 |
| produced    |        0 |        0 |        1 |
| propagated  |        1 |        0 |        0 |
| referred    |        0 |        1 |        0 |
| related     |        0 |        1 |        0 |
| resulting   |        1 |        0 |        0 |
| rootstocks  |        1 |        0 |        0 |
| rutaceae    |        0 |        1 |        0 |
| seed        |        1 |        0 |        0 |
| several     |        0 |        0 |        1 |
| sinensis    |        0 |        1 |        0 |
| size        |        1 |        0 |        0 |
| species     |        0 |        1 |        0 |
| sweet       |        0 |        1 |        0 |
| tree        |        1 |        0 |        0 |
| trees       |        1 |        0 |        0 |
| used        |        0 |        0 |        1 |
------------------------------------------------
| Totals      |       16 |       19 |       24 |
------------------------------------------------